import React from 'react';

function Contact() {
  return (
    <div>
      <h1>Welcome to the Contact page of the Student Management Portal</h1>
    </div>
  );
}

export default Contact;
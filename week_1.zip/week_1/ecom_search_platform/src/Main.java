public class Main {
    public static void main(String[] args) {
        Product[] products = {
                new Product(1, "Laptop", "Electronics"),
                new Product(2, "Shoes", "Footwear"),
                new Product(3, "Watch", "Accessories"),
                new Product(4, "Mobile", "Electronics"),
                new Product(5, "T-Shirt", "Clothing")
        };

        System.out.println("🔍 Linear Search:");
        Product result1 = SearchUtil.linearSearch(products, "Watch");
        System.out.println(result1 != null ? result1 : "Product not found.");

        System.out.println("\n🔍 Binary Search:");
        SearchUtil.sortProductsByName(products);
        Product result2 = SearchUtil.binarySearch(products, "Watch");
        System.out.println(result2 != null ? result2 : "Product not found.");
    }
}

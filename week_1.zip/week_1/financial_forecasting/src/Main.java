public class Main {
    public static void main(String[] args) {
        double initial = 10000;
        double rate = 0.08;
        int years = 5;                  

        double forecast = FinancialForecast.futureValue(initial, rate, years);
        System.out.printf("📈 Forecasted Value after %d years: ₹%.2f\n", years, forecast);
    }
}
